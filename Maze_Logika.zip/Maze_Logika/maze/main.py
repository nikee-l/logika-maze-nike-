from pygame import *

# Initialize pygame engine
init()


class GameSprite(sprite.Sprite):
    """Base class for all game objects. Inherits from pygame.sprite.Sprite"""

    def __init__(self, player_image, player_x, player_y, size_x, size_y):
        """
        Initialize sprite with image and position
        Args:
            player_image (str): Path to sprite image
            player_x, player_y (int): Initial coordinates
            size_x, size_y (int): Sprite dimensions
        """
        sprite.Sprite.__init__(self)
        # Load and scale the sprite image
        self.image = transform.scale(image.load(player_image), (size_x, size_y))
        # Create rectangle for collision detection
        self.rect = self.image.get_rect()
        self.rect.x = player_x
        self.rect.y = player_y

    def reset(self):
        """Draw sprite on the game window"""
        window.blit(self.image, (self.rect.x, self.rect.y))


class Player(GameSprite):
    """Player class with movement and collision handling"""

    def __init__(
        self,
        player_image,
        player_x,
        player_y,
        size_x,
        size_y,
        player_x_speed,
        player_y_speed,
    ):
        GameSprite.__init__(self, player_image, player_x, player_y, size_x, size_y)

        self.x_speed = player_x_speed
        self.y_speed = player_y_speed

    def update(self):
        """
        Update player position and handle collisions
        Checks for:
        - Screen boundaries
        - Platform collisions
        - Vertical and horizontal movement
        """
        if (
            packman.rect.x <= win_width - 80
            and packman.x_speed > 0
            or packman.rect.x >= 0
            and packman.x_speed < 0
        ):
            self.rect.x += self.x_speed
        platforms_touched = sprite.spritecollide(self, barriers, False)
        if self.x_speed > 0:
            for p in platforms_touched:
                self.rect.right = min(self.rect.right, p.rect.left)
        elif self.x_speed < 0:
            for p in platforms_touched:
                self.rect.left = max(self.rect.left, p.rect.right)
        if (
            packman.rect.y <= win_height - 80
            and packman.y_speed > 0
            or packman.rect.y >= 0
            and packman.y_speed < 0
        ):
            self.rect.y += self.y_speed

        platforms_touched = sprite.spritecollide(self, barriers, False)
        if self.y_speed > 0:
            for p in platforms_touched:
                self.y_speed = 0
                if p.rect.top < self.rect.bottom:
                    self.rect.bottom = p.rect.top
        elif self.y_speed < 0:
            for p in platforms_touched:
                self.y_speed = 0
                self.rect.top = max(self.rect.top, p.rect.bottom)

    def fire(self):
        """Create and shoot a bullet from player position"""
        bullet = Bullet(
            "assets/bullet.png", self.rect.right, self.rect.centery, 15, 20, 15
        )
        bullets.add(bullet)


class Enemy(GameSprite):
    """Enemy class with basic AI movement pattern"""

    side = "left"  # Initial movement direction

    def __init__(self, player_image, player_x, player_y, size_x, size_y, player_speed):
        GameSprite.__init__(self, player_image, player_x, player_y, size_x, size_y)
        self.speed = player_speed

    def update(self):
        """
        Update enemy position
        Implements basic left-right movement pattern with boundary checking
        """
        if self.rect.x <= 420:
            self.side = "right"
        if self.rect.x >= win_width - 85:
            self.side = "left"
        if self.side == "left":
            self.rect.x -= self.speed
        else:
            self.rect.x += self.speed


class Bullet(GameSprite):
    """Projectile class for player weapons"""

    def __init__(self, player_image, player_x, player_y, size_x, size_y, player_speed):
        # Викликаємо конструктор класу (Sprite):
        GameSprite.__init__(self, player_image, player_x, player_y, size_x, size_y)
        self.speed = player_speed

    def update(self):
        """Move bullet and remove it if it goes off screen"""
        self.rect.x += self.speed
        # зникає, якщо дійде до краю екрана
        if self.rect.x > win_width + 10:
            self.kill()


# Game window settings
win_width = 700
win_height = 700
display.set_caption("Лабіринт")  # Set window title to "Labyrinth"
window = display.set_mode((win_width, win_height))
back = (119, 210, 223)  # Background color (light blue)

# Create sprite groups for collision detection and rendering
barriers = sprite.Group()  # Walls and obstacles
bullets = sprite.Group()  # Player projectiles
monsters = sprite.Group()  # Enemy characters

# Create maze walls
w1 = GameSprite(
    "assets/wall_v.png", win_width / 2 - win_width / 3, win_height / 2, 300, 50
)  # Horizontal wall
w2 = GameSprite("assets/wall.png", 370, 100, 50, 400)  # Vertical wall
w3 = GameSprite(
    "assets/wall_v.png", win_width / 2 + win_width / 3, win_height / 3, 300, 50
)
barriers.add(w1)
barriers.add(w2)
barriers.add(w3)

# Initialize player and goal
packman = Player(
    "assets/ghost.png", 5, win_height - 80, 80, 80, 0, 0
)  # Player starts at bottom-left
final_sprite = GameSprite(
    "assets/pacman.png", win_width - 85, win_height - 100, 80, 80
)  # Goal at bottom-right

# Create enemies
monster1 = Enemy("assets/cyborg.png", win_width - 80, 150, 80, 80, 5)  # Fast enemy
monster2 = Enemy(
    "assets/cyborg.png", win_width - 20, 320, 20, 20, 8
)  # Small, faster enemy
monsters.add(monster1)
monsters.add(monster2)

# Game state flags
finish = False  # True when game ends (win/lose)
run = True  # Main game loop control

# Main game loop
while run:
    time.delay(50)  # Control game speed

    # Event handling loop
    for e in event.get():
        if e.type == QUIT:
            run = False
        # Handle keyboard input for player movement and actions
        elif e.type == KEYDOWN:
            if e.key == K_LEFT:
                packman.x_speed = -5
            elif e.key == K_RIGHT:
                packman.x_speed = 5
            elif e.key == K_UP:
                packman.y_speed = -5
            elif e.key == K_DOWN:
                packman.y_speed = 5
            elif e.key == K_SPACE:
                packman.fire()

        elif e.type == KEYUP:
            if e.key == K_LEFT:
                packman.x_speed = 0
            elif e.key == K_RIGHT:
                packman.x_speed = 0
            elif e.key == K_UP:
                packman.y_speed = 0
            elif e.key == K_DOWN:
                packman.y_speed = 0

    if not finish:
        # Game logic when game is active
        window.fill(back)  # Clear screen with background color

        # Update game objects
        packman.update()
        bullets.update()

        # Draw all game objects
        packman.reset()
        w1.reset()
        w2.reset()
        bullets.draw(window)
        barriers.draw(window)
        final_sprite.reset()

        # Handle collisions
        sprite.groupcollide(monsters, bullets, True, True)  # Bullets destroy monsters
        monsters.update()
        monsters.draw(window)
        sprite.groupcollide(
            bullets, barriers, True, False
        )  # Bullets are destroyed by barriers

        # Check win/lose conditions
        if sprite.spritecollide(packman, monsters, False):
            # Player loses if touched by monster
            finish = True
            img = image.load("assets/defeat.png")
            d = img.get_width() // img.get_height()
            window.fill((255, 255, 255))
            window.blit(transform.scale(img, (win_height * d, win_height)), (0, 0))

        if sprite.collide_rect(packman, final_sprite):
            # Player wins if reaching the goal
            finish = True
            img = image.load("assets/win.png")
            window.fill((255, 255, 255))
            window.blit(transform.scale(img, (win_width, win_height)), (0, 0))

    # Update display
    display.update()
